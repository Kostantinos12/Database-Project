/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airliner;

import airliner.database.Booking;
import airliner.database.Customer;
import airliner.database.Flight;
import airliner.database.Line;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class AirLiner {

    public static int menu(){
        Scanner input = new Scanner(System.in);
        System.out.println("1. Καταχώρηση Πτήσης");
        System.out.println("2. Καταχώρηση Πελάτη");
        System.out.println("3. Καταχώρηση Κράτησης");
        System.out.println("4. Πτήσεις Αερογραμμών");
        System.out.println("5. Πτήσεις που είναι πλήρεις");
        System.out.println("6. Διαθέσιμες πτήσεις μεταξύ Τορόντο - Νέας Υόρκης");
        System.out.println("7. Κράτηση σε πτήση αερογραμμής");
        System.out.println("8. Εξόφληση Κράτησης");
        System.out.println("9. Ακυρωμένες Κρατήσεις");
        System.out.println("0. Έξοδος");
        System.out.println("-----------------------------------------------------");
        System.out.print("Επιλέξτε Ενέργεια:");
        int r = Integer.parseInt(input.nextLine());
        return r;
    }
    public static void chooseAction(int x){
        if (x==1){
            Flight F = new Flight();
            if (F.insertIntoDatabase()){
                System.out.println("Η καταχώρηση της πτήσης έγινε με επιτυχία");  
            }
            else {
                System.out.println("Η καταχώρηση της πτήσης δεν έγινε με επιτυχία");
            }
        }
        else if (x==2){
            Customer C = new Customer();
            if (C.insertIntoDatabase()){
                System.out.println("Η καταχώρηση του πελάτη έγινε με επιτυχία");  
            }
            else {
                System.out.println("Η καταχώρηση του πελάτη δεν έγινε με επιτυχία");
            }
        }
        else if (x==3){
            Booking B = new Booking();
            if (B.insertIntoDatabase()){
                System.out.println("Η καταχώρηση της κράτησης έγινε με επιτυχία");  
            }
            else {
                System.out.println("Η καταχώρηση της κράτησης δεν έγινε με επιτυχία");
            }
        }
        else if (x==4){
            System.out.print("Κωδικός Αερογραμμής:");
            Scanner input = new Scanner(System.in).useDelimiter("\n");
            int lineCode = input.nextInt();
            Line L = new Line();
            L.setId(lineCode);
            L.getFromDb();
            System.out.println(L.toString());
            L.getFlightsFromDb();
            for (int i=0;i<L.getFlightList().size();i++){
                System.out.println(L.getFlightList().get(i).toString());
            }
            
            
        }
        else if (x==5){
            ArrayList<Flight> FS = Flight.getFullFromDb();
             if ((FS==null)||(FS.size()==0)){
                System.out.println("Δεν βρέθηκαν εγγραφές!");
            }
            else {
                for (int i=0;i<FS.size();i++){
                    System.out.println(FS.get(i).toString());
                }
            }
        }
        else if (x==6){
            ArrayList<Flight> FS = Flight.getFromToFlights("JFK","YYZ");
            if ((FS==null)||(FS.size()==0)){
                System.out.println("Δεν βρέθηκαν εγγραφές!");
            }
            else {
                for (int i=0;i<FS.size();i++){
                    System.out.println(FS.get(i).toString());
                }
            }
        }
        else if (x==7){
            Booking B = new Booking();
            if (B.insertIntoDatabase()){
                System.out.println("Η καταχώρηση της κράτησης έγινε με επιτυχία");  
            }
            else {
                System.out.println("Η καταχώρηση της κράτησης δεν έγινε με επιτυχία");
            }
        }
        else if (x==8){
            System.out.print("Δώστε το κωδικό της κράτησης:");
            Scanner input = new Scanner(System.in).useDelimiter("\n");
            int bookingCode = input.nextInt();
            if (Booking.getAndExecuteBooking(bookingCode)){
                System.out.println("Η κράτηση επικυρώθηκε");
            }
            else {
                System.out.println("Η κράτηση δεν επικυρώθηκε");
            }
            
        }
        else if (x==9){
            System.out.print("Δώστε το κωδικό της πτήσης:");
            Scanner input = new Scanner(System.in).useDelimiter("\n");
            Flight F = new Flight();
            F.setId(input.nextInt());
            ArrayList<Booking> BS = F.getBookingRejectedFromDb();
            for (int i=0; i<BS.size(); i++){
                System.out.println(BS.get(i).toString());
                if (BS.get(i).deleteFromDb()){
                    System.out.println("*** ΔΙΑΓΡΑΦΗΚΕ ***");
                }
            }
        }
    }
       
                
    
    public static void main(String[] args) {
        int c = menu();
        while (c!=0){
            chooseAction(c);
            c = menu();
        }
        
    }
    
}
