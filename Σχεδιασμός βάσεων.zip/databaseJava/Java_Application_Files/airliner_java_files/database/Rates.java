package airliner.database;

import java.util.Date;

public class Rates {

    private Integer id;
    private int country1;
    private double rate;
    private Date ratedate;
    private Country country;

    public Rates() {
    }

    public Rates(Integer id) {
        this.id = id;
    }

    public Rates(Integer id, int country1, double rate, Date ratedate) {
        this.id = id;
        this.country1 = country1;
        this.rate = rate;
        this.ratedate = ratedate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCountry1() {
        return country1;
    }

    public void setCountry1(int country1) {
        this.country1 = country1;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public Date getRatedate() {
        return ratedate;
    }

    public void setRatedate(Date ratedate) {
        this.ratedate = ratedate;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

}
