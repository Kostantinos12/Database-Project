package airliner.database;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Flight {

    private Integer id;
    private Date departuretime;
    private int businessSeats;
    private int economySeats;
    private int businessSeatsBooked;
    private int economySeatsBooked;
    private int smokingSeats;
    private int smokingSeatsBooked;
    private Line line;
    private ArrayList<Booking> bookingList;

    public Flight() {
        this.id = 0;
        this.departuretime = new Date();
        this.businessSeats = 0;
        this.economySeats = 0;
        this.businessSeatsBooked = 0;
        this.economySeatsBooked = 0;
        this.smokingSeats = 0;
        this.smokingSeatsBooked = 0;
        this.line = new Line();
        this.bookingList = new ArrayList<>();
    }

    public Flight(Integer id) {
        this.id = id;
    }

    public Flight(Integer id, Date departuretime, int businessSeats, int economySeats, int businessSeatsBooked, int economySeatsBooked, int smokingSeats, int smokingSeatsBooked) {
        this.id = id;
        this.departuretime = departuretime;
        this.businessSeats = businessSeats;
        this.economySeats = economySeats;
        this.businessSeatsBooked = businessSeatsBooked;
        this.economySeatsBooked = economySeatsBooked;
        this.smokingSeats = smokingSeats;
        this.smokingSeatsBooked = smokingSeatsBooked;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(Date departuretime) {
        this.departuretime = departuretime;
    }

    public int getBusinessSeats() {
        return businessSeats;
    }

    public void setBusinessSeats(int businessSeats) {
        this.businessSeats = businessSeats;
    }

    public int getEconomySeats() {
        return economySeats;
    }

    public void setEconomySeats(int economySeats) {
        this.economySeats = economySeats;
    }

    public int getBusinessSeatsBooked() {
        return businessSeatsBooked;
    }

    public void setBusinessSeatsBooked(int businessSeatsBooked) {
        this.businessSeatsBooked = businessSeatsBooked;
    }

    public int getEconomySeatsBooked() {
        return economySeatsBooked;
    }

    public void setEconomySeatsBooked(int economySeatsBooked) {
        this.economySeatsBooked = economySeatsBooked;
    }

    public int getSmokingSeats() {
        return smokingSeats;
    }

    public void setSmokingSeats(int smokingSeats) {
        this.smokingSeats = smokingSeats;
    }

    public int getSmokingSeatsBooked() {
        return smokingSeatsBooked;
    }

    public void setSmokingSeatsBooked(int smokingSeatsBooked) {
        this.smokingSeatsBooked = smokingSeatsBooked;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public ArrayList<Booking> getBookingList() {
        return bookingList;
    }

    public void setBookingList(ArrayList<Booking> bookingList) {
        this.bookingList = bookingList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flight)) {
            return false;
        }
        Flight other = (Flight) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString(){
        String str = "("+this.id+")";
        str+="ΑΕΡΟΓΡΑΜΜΗ:"+this.line.toString();
        str+="ΗΜΕΡΟΜΗΝΙΑ-ΩΡΑ ΑΝΑΧΩΡΗΣΗΣ:"+this.departuretime;
        return str;
    }
    
    public boolean insertIntoDatabase(){
        Scanner input = new Scanner(System.in).useDelimiter("\n");
        System.out.print("Κωδικός Αερογραμμής:");
        this.line.setId(input.nextInt());
        System.out.print("Ημερομηνία/'Ωρα αναχώρησης (ΗΗ-ΜΜ-ΕΕΕΕ ΩΩ(24):ΛΛ);");
        try {  
            Date date1=new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(input.next());
            this.departuretime = date1;
        } catch (ParseException ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("Πλήθος Business Class Θέσεων:");
        this.businessSeats = input.nextInt();
        System.out.print("Πλήθος Economy Class Θέσεων:");
        this.economySeats = input.nextInt();
        System.out.print("Πλήθος Θέσεων Καπνιστών:");
        this.smokingSeats = input.nextInt();
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");  
        String strDate = dateFormat.format(this.departuretime);  
        
        String sql = "insert into flight(`line`, `departuretime`, `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked`) values(";
        sql+="'" + this.getLine().getId() + "',";
        
        sql+="str_to_date('" + strDate + "','%d-%m-%Y %H:%i'),";
        sql+="'" + this.businessSeats + "',";
        sql+="'" + this.economySeats + "',";
        sql+="'0',";
        sql+="'0',";
        sql+="'" + this.smokingSeats + "',";
        sql+="'0')";
        
        Database db = new Database();
        db.connect();
        boolean result = db.update(sql);
        db.disconnect();
        return result;
    }
    
    
    
    public void getFromDb(){
        String sql = "select 0,`line`, date_format(`departuretime`,'%d-%m-%Y %H:%i'), `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked` from flight where `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            
            if (rs.next()){
                Line L = new Line();
                L.setId(rs.getInt(2));
                L.getFromDb();
                L.getFlightsFromDb();
                this.setLine(L);
                
                try {  
                    Date date1=new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(rs.getString(3));
                    this.setDeparturetime(date1);
                } catch (ParseException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setBusinessSeats(rs.getInt(4));
                this.setEconomySeats(rs.getInt(5));
                this.setBusinessSeatsBooked(rs.getInt(6));
                this.setEconomySeatsBooked(rs.getInt(7));
                this.setSmokingSeats(rs.getInt(8));
                this.setSmokingSeatsBooked(rs.getInt(9));
            }
        }
         catch (SQLException ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
    public static ArrayList<Flight> getFullFromDb(){
        String sql = "SELECT `id`, `line`, date_format(`departuretime`,'%d-%m-%Y %H:%i'), `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked` FROM `flight` WHERE  ";
        sql += " `business_seats` = `business_seats_booked` and";
        sql += " `economy_seats` = `economy_seats_booked` and";
        sql += " `smoking_seats` = `smoking_seats_booked` and departuretime > CURRENT_TIMESTAMP() ";
        sql += " order by `departuretime`" ;
        ArrayList<Flight> FS = new ArrayList<>();
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            
            while(rs.next()){
                Flight F = new Flight();
                F.setId(rs.getInt(1));
                Line L = new Line();
                L.setId(rs.getInt(2));
                L.getFromDb();
                L.getFlightsFromDb();
                F.setLine(L);
                
                try {  
                    Date date1=new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(rs.getString(3));
                    F.setDeparturetime(date1);
                } catch (ParseException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                F.setBusinessSeats(rs.getInt(4));
                F.setEconomySeats(rs.getInt(5));
                F.setBusinessSeatsBooked(rs.getInt(6));
                F.setEconomySeatsBooked(rs.getInt(7));
                F.setSmokingSeats(rs.getInt(8));
                F.setSmokingSeatsBooked(rs.getInt(9));
                FS.add(F);
            }
            database.disconnect();
            return FS;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
        
        
    }
    
    
    
    public static ArrayList<Flight> getFromToFlights(String from, String to){
        String sql = "SELECT `flight`.`id`, `line`, date_format(`departuretime`,'%d-%m-%Y %H:%i'), `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked` ";
        sql += "  FROM `flight`,`line`,`city` a,`city` b WHERE  ";
        sql += " a.id = line.depart and b.id=line.arrive and line.id = flight.line ";
        sql += " and ((a.airportcode='"+from+"' and b.airportcode='"+to+"') or";
        sql += " (a.airportcode='"+to+"' and b.airportcode='"+from+"'))  and departuretime > CURRENT_TIMESTAMP()  ";
        sql += " and ((`business_seats`>`business_seats_booked`) or (`economy_seats`>`economy_seats_booked`) or (`smoking_seats` > `smoking_seats_booked`)) " ;
        sql += " order by `departuretime`" ;
        ArrayList<Flight> FS = new ArrayList<>();
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            
            while(rs.next()){
                Flight F = new Flight();
                F.setId(rs.getInt(1));
                Line L = new Line();
                L.setId(rs.getInt(2));
                L.getFromDb();
                L.getFlightsFromDb();
                F.setLine(L);
                
                try {  
                    Date date1=new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(rs.getString(3));
                    F.setDeparturetime(date1);
                } catch (ParseException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                F.setBusinessSeats(rs.getInt(4));
                F.setEconomySeats(rs.getInt(5));
                F.setBusinessSeatsBooked(rs.getInt(6));
                F.setEconomySeatsBooked(rs.getInt(7));
                F.setSmokingSeats(rs.getInt(8));
                F.setSmokingSeatsBooked(rs.getInt(9));
                FS.add(F);
            }
            database.disconnect();
            return FS;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
        
        
    }
    
    public ArrayList<Booking> getBookingRejectedFromDb(){
        ArrayList<Booking> BS = new ArrayList<Booking>();
        String sql = "SELECT `id`, `flight`, `customer`, `city`, DATE_FORMAT(`datetime`,'%d-%m-%Y'), `paid`, `seat`, `status` FROM `booking` WHERE  ";
        sql += " `flight` = '"+this.id+"' and `status`='B'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);

            while(rs.next()){
                Booking B = new Booking();
                B.setId(rs.getInt(1));
                B.setFlight(this);
                Customer C = new Customer();
                C.setId(rs.getInt(3));
                City Ci = new City();
                Ci.setId(rs.getInt(4));
                B.setCity(Ci);
                
                try {  
                    Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(rs.getString(5));
                    B.setDatetime(date1);
                } catch (ParseException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                B.setPaid(rs.getInt(5));
                B.setSeat(rs.getString(6));
                B.setStatus(rs.getString(7));
                BS.add(B);
                
            }
            database.disconnect();
            return BS;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
    }
    
}
