/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airliner.database;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Admin
 */
public class Company {
    private int id;
    private String name;
    private Country country;

    public Company() {
        this.id = 0;
        this.name = "";
        this.country = new Country();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
    
    public String toString(){
        return "ΕΤΑΙΡΕΙΑ:"+this.name;
    }
    
    public void getFromDb(){
        String sql="SELECT `id`, `name`, `country` FROM `company` WHERE `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.name = rs.getString(2);
                this.country.setId(rs.getInt(3));
                this.country.getFromDb();
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
}
