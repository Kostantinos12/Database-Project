package airliner.database;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class Booking {

    
    private Integer id;
    private City city;
    private Date datetime;
    private double paid;
    private String seat;
    private String status;
    private Flight flight;
    private Customer customer;

    public Booking() {
        this.id = 0;
        this.city = new City();
        this.datetime = null;
        this.paid = 0;
        this.seat = "";
        this.flight = new Flight();
        this.customer = new Customer();
        this.status = "";
    }

    public Booking(Integer id) {
        this.id = id;
    }

    public Booking(Integer id, City city, Date datetime, double paid, String seat) {
        this.id = id;
        this.city = city;
        this.datetime = datetime;
        this.paid = paid;
        this.seat = seat;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Date getDatetime() {
        return datetime;
    }

    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }

    public double getPaid() {
        return paid;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Booking)) {
            return false;
        }
        Booking other = (Booking) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString(){
        String str = "  ΠΕΛΑΤΗΣ:"+this.customer.toString();
        str+="ΠΤΗΣΗ:"+this.flight.toString();
        str+="ΠΡΟΚΑΤΑΒΟΛΗ:"+this.paid;
        str+="ΗΜΕΡΟΜΗΝΙΑ ΚΡΑΤΗΣΗΣ:"+this.datetime.toString();
        str+="ΠΟΛΗ ΚΡΑΤΗΣΗΣ"+this.city.toString();
        str+="ΚΑΤΑΤΑΣΗ:"+this.status+"  ";
        return str;
    }
    
    public boolean deleteFromDb(){
        String sql="delete from booking where id='"+this.id+"'";
        Database db = new Database();
        db.connect();
        boolean result = db.update(sql);
        db.disconnect();
        return result;
    }
    
    public boolean insertIntoDatabase(){
        Scanner input = new Scanner(System.in).useDelimiter("\n");;
        System.out.print("Κωδικός Πτήσης:");
        this.flight.setId(input.nextInt());
        this.flight.getFromDb();
        System.out.println("Επιλέξατε:"+this.flight.toString());
        System.out.print("Κωδικός Πελάτη:");
        this.customer.setId(input.nextInt());
        this.customer.getFromDatabase();
        System.out.println("Επιλέξατε:"+this.customer.toString());
        System.out.print("Κωδικός Πόλης Κράτησης:");
        this.city.setId(input.nextInt());
        this.city.getFromDb();
        System.out.println("Επιλέξατε:"+this.city.toString());
        System.out.print("Είδος Θέσης (BUSINESS-ECONOMY-SMOKING):");
        this.seat = input.next();
        int con=1;
        if ((this.seat=="BUSINESS")&&(this.flight.getBusinessSeats()-this.flight.getBusinessSeatsBooked()<1)){
            con =0;
        }
        else if ((this.seat=="ECONOMY")&&(this.flight.getEconomySeats()-this.flight.getEconomySeatsBooked()<1)){
            con = 0;
        }
        else if ((this.seat=="SMOKING")&&(this.flight.getSmokingSeats()-this.flight.getSmokingSeatsBooked()<1)){
            con = 0;
        }
        if (con == 0){
            System.out.println("Δεν υπάρχουν  διαθέσιμες θέσεις");
            return false;
        }
        else {
            double cost = this.flight.getLine().getPrice();
            if (this.seat.equals("BUSINESS")){
                cost = 1.5*cost+cost*this.flight.getLine().getDepart().getTax();
            }
            System.out.println("Το κόστος είναι:"+cost);
            System.out.print("Προκαταβολή:");
            this.paid = input.nextDouble();
            if (this.paid>=cost){
                this.status="A";
            }
            else if (this.paid>=0){
                this.status="C";
            }
            else if (this.paid<0){
               this.paid=0;
               this.status = "C";
            }



            String sql = "insert into booking(`flight`, `customer`, `city`, `datetime`, `paid`, `seat`,`status`) values (";
            sql+="'"+this.flight.getId()+"', ";
            sql+="'"+this.customer.getId()+"', ";
            sql+="'"+this.city.getId() +"', ";
            sql+="CURRENT_TIMESTAMP(), ";
            sql+="'"+this.paid+"', ";
            sql+="'"+this.seat+"', ";
            sql+="'"+this.status+"') ";
            Database db = new Database();
            db.connect();
            boolean result = db.update(sql);
            sql="update flight set ";
            if (this.seat.equals("ECONOMY")){
                sql+=" economy_seats_booked = economy_seats_booked + 1 ";
            }
            else if (this.seat.equals("BUSINESS")){
                sql+=" business_seats_booked = business_seats_booked + 1 ";
            }
            else if (this.seat.equals("SMOKING")){
                sql+=" smoking_seats_booked = smoking_seats_booked + 1 ";
            }
            sql+= " where id='"+this.flight.getId()+"'";
            result = (result && db.update(sql));
            db.disconnect();
            return result;
        }
        
    }
    
    
    public static boolean getAndExecuteBooking(int code){
        boolean result = false;
        
        String sql="select `flight`, `customer`, `city`, `datetime`, `paid`, `seat`,`city`.`tax`*(SELECT `rate` from `rates` where country=(select `country` from `prefecture` where `id` = `city`.`prefecture`) order by `ratedate` limit 0,1),`line`.`price` from `booking`,`flight`,`line`,`city` ";
        sql += " where `booking`.`id`='"+code+"' and `flight`.`id` = `booking`.`flight`";
        sql += " and `flight`.`line`=`line`.`id` and `line`.`depart` = `city`.`id`";
         
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                
                double cost = rs.getDouble(8);
                if (rs.getString(6).equals("BUSINESS")){
                    cost = 1.5*cost;
                }
                cost = cost+cost*rs.getDouble(7);
                System.out.println("Η πτήση κοστίζει "+cost+" και έχουν καταβληθεί "+rs.getDouble(5) );
                System.out.print("Καταβλήθηκε το υπόλοιπο; (1->ΝΑΙ / 2->ΟΧΙ):");
                Scanner input = new Scanner(System.in).useDelimiter("\n");

                if (input.nextInt()==1){
                    sql = "update booking set paid='"+cost+"' where `id`='"+code+"'";
                    result = database.update(sql);

                }
                database.disconnect();
                return result;
            }
            else {
                return false;
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }
    
    
}
