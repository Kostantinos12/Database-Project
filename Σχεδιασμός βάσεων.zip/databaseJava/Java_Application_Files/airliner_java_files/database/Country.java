package airliner.database;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Country {

    private Integer id;
    private String name;
    private String phonecode;
    private Rates rates;
    
    public Country() {
    }

    public Country(Integer id) {
        this.id = id;
    }

    public Country(Integer id, String name, String phonecode) {
        this.id = id;
        this.name = name;
        this.phonecode = phonecode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhonecode() {
        return phonecode;
    }

    public void setPhonecode(String phonecode) {
        this.phonecode = phonecode;
    }

    public Rates getRates() {
        return rates;
    }

    public void setRates(Rates rates) {
        this.rates = rates;
    }


    @Override
    public String toString() {
        return this.name;
    }
    
    public void getFromDb(){
        String sql="SELECT `id`, `name`, `phonecode` FROM `country` WHERE `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.name = rs.getString(2);
                this.phonecode = rs.getString(3);
            }
            
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    
}
