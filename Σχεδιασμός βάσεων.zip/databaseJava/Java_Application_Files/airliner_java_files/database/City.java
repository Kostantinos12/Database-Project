package airliner.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class City {

    private Integer id;
    private String name;
    private double tax;
    private Prefecture prefecture;
    private String airportcode;
    private List<Line> lineList;
    private List<Line> lineList1;
    private List<Customer> customerList;

    public City() {
        this.id = 0;
        this.name = "";
        this.tax = 0;
        this.prefecture = new Prefecture();
        this.airportcode = "";
    }

    public City(Integer id) {
        this.id = id;
    }

    public City(Integer id, String name, double tax) {
        this.id = id;
        this.name = name;
        this.tax = tax;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public Prefecture getPrefecture() {
        return prefecture;
    }

    public String getAirportcode() {
        return airportcode;
    }

    public void setAirportcode(String airportcode) {
        this.airportcode = airportcode;
    }
    
    public void setPrefecture(Prefecture prefecture) {
        this.prefecture = prefecture;
    }

    public List<Line> getLineList() {
        return lineList;
    }

    public void setLineList(List<Line> lineList) {
        this.lineList = lineList;
    }

    public List<Line> getLineList1() {
        return lineList1;
    }

    public void setLineList1(List<Line> lineList1) {
        this.lineList1 = lineList1;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof City)) {
            return false;
        }
        City other = (City) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.name+" "+this.prefecture;
    }
    
    public void getFromDb(){
        String sql="SELECT `id`, `name`, `prefecture`, `tax`,`airportcode` FROM `city` WHERE `id`='"+this.id+"';";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.name = rs.getString(2);
                this.prefecture.setId(rs.getInt(3));
                this.tax = rs.getDouble(4);
                this.airportcode = rs.getString(5);
                this.prefecture.getFromDb();
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}
