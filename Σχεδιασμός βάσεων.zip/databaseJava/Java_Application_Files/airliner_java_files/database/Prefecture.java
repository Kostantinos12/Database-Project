package airliner.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Prefecture{

    private Integer id;
    private String name;
    private String phonecode;
    private int timezone;
    private Country country;

    public Prefecture() {
        this.id = 0;
        this.name = "";
        this.phonecode = "";
        this.timezone = 0;
        this.country = new Country();
    }
    

    public Prefecture(Integer id) {
        this.id = id;
    }

    public Prefecture(Integer id, String name, String phonecode, int timezone) {
        this.id = id;
        this.name = name;
        this.phonecode = phonecode;
        this.timezone = timezone;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhonecode() {
        return phonecode;
    }

    public void setPhonecode(String phonecode) {
        this.phonecode = phonecode;
    }

    public int getTimezone() {
        return timezone;
    }

    public void setTimezone(int timezone) {
        this.timezone = timezone;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return this.name+" "+this.country.toString();
    }
    
    public void getFromDb(){
        String sql="SELECT `id`, `name`, `country`, `phonecode`, `timezone` FROM `prefecture` WHERE `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.name = rs.getString(2);
                this.country.setId(rs.getInt(3));
                this.phonecode = rs.getString(4);
                this.timezone=(rs.getInt(5));
                this.country.getFromDb();
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}
