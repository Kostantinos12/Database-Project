/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airliner.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Database {
    private String url;
    private String username;
    private String password;
    private Connection connection;
    public Statement stmt;
    public Database(){
        this.url = "jdbc:mysql://localhost:3306/airlines?characterEncoding=utf8";
        this.username = "root";
        this.password = "";
    }
    //ΣΥΝΔΕΣΗ ΣΤΗ ΒΑΣΗ
    public void connect(){
        
        try  {
            this.connection = DriverManager.getConnection(this.url, this.username, this.password);
            stmt = this.connection.createStatement();
            stmt.executeUpdate("set names 'utf8'");
            
        } catch (SQLException e) {
            //e.printStackTrace();
            //throw new IllegalStateException("Cannot connect the database!", e);
        }
    }
    //ΑΠΟΣΥΝΔΕΣΗ ΑΠΟ ΤΗ ΒΑΣΗ
    public void disconnect(){
        try {
            //this.connection.commit();
            this.connection.close();
            
        } catch (SQLException ex) {
            //Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean update(String sql){
        ResultSet rs;
        try {
            stmt = this.connection.createStatement();
            stmt.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
            return true;
        } catch (SQLException ex) {
            //Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ResultSet query(String sql){
        ResultSet rs;
        try {
            stmt = this.connection.createStatement();
            rs = stmt.executeQuery(sql) ;
            return rs;
        } catch (SQLException ex) {
            //Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    
}
