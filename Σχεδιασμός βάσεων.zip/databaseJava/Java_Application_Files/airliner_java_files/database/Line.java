package airliner.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Line{

    private Integer id;
    private String description;
    private int duration;
    private double price;
    private ArrayList<Flight> flightList;
    private City depart;
    private City arrive;
    private Company company;

    public Line() {
        this.id = 0;
        this.description = "";
        this.duration = 0;
        this.price = 0;
        this.flightList = new ArrayList<>();
        this.depart = new City();
        this.arrive = new City();
        this.company = new Company();
    }

    public Line(Integer id) {
        this.id = id;
    }

    public Line(Integer id, String description, int duration, double price) {
        this.id = id;
        this.description = description;
        this.duration = duration;
        this.price = price;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public ArrayList<Flight> getFlightList() {
        return flightList;
    }

    public void setFlightList(ArrayList<Flight> flightList) {
        this.flightList = flightList;
    }

    public City getDepart() {
        return depart;
    }

    public void setDepart(City depart) {
        this.depart = depart;
    }

    public City getArrive() {
        return arrive;
    }

    public void setArrive(City arrive) {
        this.arrive = arrive;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Line)) {
            return false;
        }
        Line other = (Line) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = this.depart.toString()+" - "+this.arrive.toString()+" ("+this.company.toString()+")";
        str+="ΔΙΑΡΚΕΙΑ ΠΤΗΣΗΣ:"+this.duration+"min";
        return str;
    }
    
    public void getFlightsFromDb(){
        String sql = "SELECT `id`, `line`, date_format(`departuretime`,'%d-%m-%Y %H:%i'), `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked` FROM `flight` WHERE  ";
        sql += " `line` = '"+this.id+"' and departuretime > CURRENT_TIMESTAMP()  ";
        sql += " and ((`business_seats`>`business_seats_booked`) or (`economy_seats`>`economy_seats_booked`) or (`smoking_seats` > `smoking_seats_booked`)) " ;
        sql += " order by `departuretime`";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            
            while(rs.next()){
                Flight F = new Flight();
                F.setId(rs.getInt(1));
                F.setLine(this);
                try {  
                    Date date1=new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(rs.getString(3));
                    F.setDeparturetime(date1);
                } catch (ParseException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                F.setBusinessSeats(rs.getInt(4));
                F.setEconomySeats(rs.getInt(5));
                F.setBusinessSeatsBooked(rs.getInt(6));
                F.setEconomySeatsBooked(rs.getInt(7));
                F.setSmokingSeats(rs.getInt(8));
                F.setSmokingSeatsBooked(rs.getInt(9));
                this.flightList.add(F);
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    public void getFromDb(){
        String sql = "SELECT `id`, `description`, `depart`, `arrive`, `duration`, `price`,`company` FROM `line` WHERE `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.description = rs.getString(2);
                this.depart.setId(rs.getInt(3));
                this.depart.getFromDb();
                this.arrive.setId(rs.getInt(4));
                this.arrive.getFromDb();
                this.duration = rs.getInt(5);
                this.price = rs.getDouble(6);
                this.company.setId(rs.getInt(7));
                this.company.getFromDb();
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    
}
