package airliner.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Customer {

   
    private Integer id;
    private String firstname;
    private String lastname;
    private String address;
    private String postalcode;
    private List<Booking> bookingList;
    private List<String> customerEmailList;
    private List<String> customerfaxesList;
    private List<String> customerphonesList;
    private City city;

    public Customer() {
        this.id = 0;
        this.firstname = "";
        this.lastname = "";
        this.address = "";
        this.postalcode = "";
        this.city = new City();
        this.bookingList  = new ArrayList<>();
        this.customerEmailList  = new ArrayList<>();
        this.customerfaxesList  = new ArrayList<>();
        this.customerphonesList  = new ArrayList<>();
    }

    public Customer(Integer id) {
        this.id = id;
    }

    public Customer(Integer id, String firstname, String lastname, String address, String postalcode) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.postalcode = postalcode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public List<Booking> getBookingList() {
        return bookingList;
    }

    public void setBookingList(List<Booking> bookingList) {
        this.bookingList = bookingList;
    }

    public List<String> getCustomerEmailList() {
        return customerEmailList;
    }

    public void setCustomerEmailList(List<String> customerEmailList) {
        this.customerEmailList = customerEmailList;
    }

    public List<String> getCustomerfaxesList() {
        return customerfaxesList;
    }

    public void setCustomerfaxesList(List<String> customerfaxesList) {
        this.customerfaxesList = customerfaxesList;
    }

    public List<String> getCustomerphonesList() {
        return customerphonesList;
    }

    public void setCustomerphonesList(List<String> customerphonesList) {
        this.customerphonesList = customerphonesList;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.firstname+" "+this.lastname+" ("+this.id+")";
    }
    
    public boolean insertIntoDatabase(){
        Scanner input = new Scanner(System.in).useDelimiter("\n");;
        System.out.print("Επώνυμο:");
        this.firstname = input.next();
        System.out.print("Όνομα:");
        this.lastname = input.next();
        System.out.print("Διεύθυνση:");
        this.address = input.next();
        System.out.print("Κωδικός Πόλης:");
        this.city.setId(input.nextInt());
        System.out.print("Ταχυδρομικός Κώδικας:");
        this.postalcode = input.next();
        System.out.print("emails (χωρισμένα με -):");
        this.customerEmailList = Arrays.asList(input.next().split("-"));
        
        System.out.print("phones (χωρισμένα με -):");
        this.customerphonesList = Arrays.asList(input.next().split("-"));
        System.out.print("faxes (χωρισμένα με -):");
        this.customerfaxesList = Arrays.asList(input.next().split("-"));
        
        String sql = "INSERT INTO `customer` (`firstname`, `lastname`, `address`, `city`, `postalcode`) VALUES (";
        
        sql+="'"+this.firstname+"', ";
        sql+="'"+this.lastname+"', ";
        sql+="'"+this.address+"', ";
        sql+="'"+this.city.getId()+"', ";
        sql+="'"+this.postalcode+"') ";
        
        Database db = new Database();
        db.connect();
        boolean result = db.update(sql);
        try {
            ResultSet rs= db.stmt.getGeneratedKeys();
            rs.next();
            for (int i=0;i<this.customerEmailList.size();i++){
                
                sql = "INSERT INTO `customer_email`(`customer`,`email`) value('"+rs.getLong(1)+"','"+this.customerEmailList.get(i)+"')";
                result = (result && db.update(sql));
            }
            for (int i=0;i<this.customerphonesList.size();i++){
                String[] x = this.customerphonesList.get(i).split(" ");
                if (x.length==2){
                    sql = "INSERT INTO `customerphones`(`customer`,`location_id`,`number`) value('"+rs.getLong(1)+"','"+x[0]+"','"+x[1]+"')";
                    result = (result && db.update(sql));
                }
                
            }
            for (int i=0;i<this.customerfaxesList.size();i++){
                String[] x = this.customerfaxesList.get(i).split(" ");
                if (x.length==2){
                    sql = "INSERT INTO `customerfaxes`(`customer`,`location_id`,`number`) value('"+rs.getLong(1)+"','"+x[0]+"','"+x[1]+"')";
                    result = (result && db.update(sql));
                }
                
            }
            db.disconnect();
            return result;
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    
    public void getFromDatabase(){
        String sql = "select `id`, `firstname`, `lastname`, `address`, `city`, `postalcode` from `customer` where `id`='"+this.id+"'";
        try {
            Database database = new Database();
            database.connect();
            ResultSet rs = database.query(sql);
            if (rs.next()){
                this.id = rs.getInt(1);
                this.firstname = rs.getString(2);
                this.lastname = rs.getString(3);
                this.address = rs.getString(4);
                this.city.setId(rs.getInt(5));
                this.postalcode = rs.getString(6);
            }
            database.disconnect();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
    
    
}
