-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 03 Ιουν 2020 στις 21:45:59
-- Έκδοση διακομιστή: 10.3.16-MariaDB
-- Έκδοση PHP: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `airlines`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL COMMENT 'Μοναδικό Αναγνωριστικό',
  `flight` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid` double NOT NULL,
  `seat` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `booking`
--

INSERT INTO `booking` (`id`, `flight`, `customer`, `city`, `datetime`, `paid`, `seat`, `status`) VALUES
(4, 2, 1, 2, '2020-06-03 15:40:14', 234, 'ECONOMY', 'C'),
(8, 2, 2, 8, '2020-06-03 18:32:39', 1260, 'SMOKING', 'A');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `prefecture` int(11) NOT NULL,
  `tax` double NOT NULL,
  `airportcode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `city`
--

INSERT INTO `city` (`id`, `name`, `prefecture`, `tax`, `airportcode`) VALUES
(1, 'Τορόντο', 2, 1, 'YYZ'),
(2, 'Μόντρεαλ', 8, 2, 'MON'),
(3, 'Νέα Υόρκη', 3, 1, 'JFK'),
(4, 'Σικάγο', 9, 2, 'CHI'),
(5, 'Λονδίνο', 4, 1, 'LON'),
(6, 'Εδιμβούργο', 10, 2, 'EDI'),
(7, 'Παρίσι', 5, 1, 'PAR'),
(8, 'Νίκαια', 11, 2, 'NIC'),
(9, 'Βόννη', 6, 1, 'VON'),
(10, 'Βερολίνο', 12, 2, 'BER'),
(11, 'Ρώμη', 1, 1, 'ROM'),
(12, 'Νάπολη', 7, 2, 'NAP');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `country` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `company`
--

INSERT INTO `company` (`id`, `name`, `country`) VALUES
(1, 'AirCan', 2),
(2, 'USAir', 3),
(3, 'BritAir', 4),
(4, 'AirFrance', 5),
(5, 'LuftAir', 6),
(6, 'ItalAir', 1);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phonecode` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `country`
--

INSERT INTO `country` (`id`, `name`, `phonecode`) VALUES
(1, 'Ιταλία', '030'),
(2, 'Καναδάς', '010'),
(3, 'ΗΠΑ', '020'),
(4, 'Ηνωμένο Βασίλειο', '040'),
(5, 'Γαλλία', '050'),
(6, 'Γερμανία', '060');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` int(11) NOT NULL,
  `postalcode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `customer`
--

INSERT INTO `customer` (`id`, `firstname`, `lastname`, `address`, `city`, `postalcode`) VALUES
(1, 'John', 'Marks', 'Address 12', 1, '12345'),
(2, 'Mark', 'Papadopoulos', 'Address 10', 11, '12389'),
(3, 'Al', 'Bandy', 'Address 20', 1, '12398'),
(4, 'Mathew', 'Brown', 'Address 22', 1, '12346'),
(5, 'Mat', 'Braze', 'Addres 23', 1, '12347'),
(6, 'Address 34', 'Mikro', '', 4, '12321'),
(7, 'Address 23', 'Jerry', '', 2, '21212'),
(8, 'Address 23', 'Jerry', '', 4, '21212'),
(9, 'Bell', 'Bill', 'Address 345', 10, '12090'),
(10, 'Bell', 'Bill', 'Gordons 123', 11, '11122'),
(11, 'Bell', 'Bill', 'Address 12', 1, '11221'),
(12, 'Frank', 'Seranton', 'Address 90', 7, '23789');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customerfaxes`
--

CREATE TABLE `customerfaxes` (
  `customer` int(11) NOT NULL,
  `location_id` varchar(5) NOT NULL,
  `number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `customerfaxes`
--

INSERT INTO `customerfaxes` (`customer`, `location_id`, `number`) VALUES
(5, '856', '987'),
(5, '965', '985'),
(8, '787', '878'),
(8, '987', '998'),
(11, '123', '45667');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customerphones`
--

CREATE TABLE `customerphones` (
  `customer` int(11) NOT NULL,
  `location_id` varchar(5) NOT NULL,
  `number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `customerphones`
--

INSERT INTO `customerphones` (`customer`, `location_id`, `number`) VALUES
(1, '555', '777'),
(5, '000', '523'),
(5, '854', '963'),
(8, '009', '009'),
(8, '098', '989'),
(9, '213', '119909'),
(9, '213', '123323'),
(10, '123', '0909090'),
(10, '123', '09898989'),
(11, '123', '56789');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customer_email`
--

CREATE TABLE `customer_email` (
  `customer` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `customer_email`
--

INSERT INTO `customer_email` (`customer`, `email`) VALUES
(1, 'email1@email.com'),
(1, 'email2@email.com'),
(1, 'email3@email.com'),
(4, 'email4@email.com'),
(4, 'email5@email.com'),
(5, 'email6@email.com'),
(5, 'email7@email.com'),
(5, 'email8@email.com'),
(6, 'email45@email.com'),
(6, 'email46@email.com'),
(8, 'jim1@jerry.fr'),
(8, 'jim@jerry.fr'),
(9, 'BellBill@gmail.com'),
(9, 'BillBell@yahoo.com'),
(10, 'Gordons@email.com'),
(11, 'email455@email.com'),
(12, 'email567@mail.com');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `flight`
--

CREATE TABLE `flight` (
  `id` int(11) NOT NULL,
  `line` int(11) NOT NULL,
  `departuretime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `business_seats` int(11) NOT NULL,
  `economy_seats` int(11) NOT NULL,
  `business_seats_booked` int(11) NOT NULL,
  `economy_seats_booked` int(11) NOT NULL,
  `smoking_seats` int(11) NOT NULL,
  `smoking_seats_booked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `flight`
--

INSERT INTO `flight` (`id`, `line`, `departuretime`, `business_seats`, `economy_seats`, `business_seats_booked`, `economy_seats_booked`, `smoking_seats`, `smoking_seats_booked`) VALUES
(1, 1, '2020-06-03 18:31:33', 100, 200, 0, 1, 100, 0),
(2, 2, '2020-06-03 19:05:32', 100, 200, 0, 0, 10, 2),
(3, 1, '2020-06-03 16:04:53', 20, 40, 20, 40, 10, 10),
(4, 2, '2020-07-01 17:30:00', 25, 45, 0, 0, 12, 0),
(6, 1, '2020-07-01 06:00:00', 12, 24, 0, 0, 2, 0);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `line`
--

CREATE TABLE `line` (
  `id` int(11) NOT NULL,
  `description` varchar(10) NOT NULL,
  `depart` int(11) NOT NULL,
  `arrive` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `price` double NOT NULL,
  `company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `line`
--

INSERT INTO `line` (`id`, `description`, `depart`, `arrive`, `duration`, `price`, `company`) VALUES
(1, 'FLT001', 10, 4, 12, 1100, 5),
(2, 'FLT002', 1, 3, 1, 1260, 4);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `prefecture`
--

CREATE TABLE `prefecture` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `country` int(11) NOT NULL,
  `phonecode` varchar(5) NOT NULL,
  `timezone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `prefecture`
--

INSERT INTO `prefecture` (`id`, `name`, `country`, `phonecode`, `timezone`) VALUES
(1, 'Νότια Ιταλία', 1, '010', 1),
(2, 'Νότιος Καναδάς', 2, '020', 12),
(3, 'Νέα Υόρκη', 3, '030', 12),
(4, 'Αγγλία', 4, '040', 2),
(5, 'Νότια Γαλλία', 5, '050', 2),
(6, 'Βόρεια Γερμανία', 6, '060', 2),
(7, 'Βόρεια Ιταλία', 1, '011', 1),
(8, 'Βόρειος Καναδάς', 2, '021', 12),
(9, 'Σικάγο', 3, '031', 14),
(10, 'Σκωτία', 4, '041', 2),
(11, 'Βόρεια Γαλλία', 5, '051', 2),
(12, 'Νότια Γερμανία', 6, '061', 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `rates`
--

CREATE TABLE `rates` (
  `id` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `rate` double NOT NULL,
  `ratedate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `rates`
--

INSERT INTO `rates` (`id`, `country`, `rate`, `ratedate`) VALUES
(1, 1, 1.09, '2020-06-01'),
(2, 2, 1, '2020-06-03'),
(3, 3, 1, '2020-06-03'),
(4, 4, 1, '2020-06-03'),
(5, 5, 1, '2020-06-03'),
(6, 6, 1, '2020-06-01');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `flight` (`flight`),
  ADD KEY `customer` (`customer`),
  ADD KEY `city` (`city`);

--
-- Ευρετήρια για πίνακα `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `airportcode` (`airportcode`),
  ADD KEY `prefecture` (`prefecture`);

--
-- Ευρετήρια για πίνακα `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country` (`country`);

--
-- Ευρετήρια για πίνακα `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phonecode` (`phonecode`);

--
-- Ευρετήρια για πίνακα `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `city` (`city`);

--
-- Ευρετήρια για πίνακα `customerfaxes`
--
ALTER TABLE `customerfaxes`
  ADD PRIMARY KEY (`customer`,`location_id`,`number`),
  ADD KEY `location_id` (`location_id`);

--
-- Ευρετήρια για πίνακα `customerphones`
--
ALTER TABLE `customerphones`
  ADD PRIMARY KEY (`customer`,`location_id`,`number`),
  ADD KEY `location_id` (`location_id`);

--
-- Ευρετήρια για πίνακα `customer_email`
--
ALTER TABLE `customer_email`
  ADD PRIMARY KEY (`email`),
  ADD KEY `email` (`email`),
  ADD KEY `customer` (`customer`);

--
-- Ευρετήρια για πίνακα `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`id`),
  ADD KEY `line` (`line`);

--
-- Ευρετήρια για πίνακα `line`
--
ALTER TABLE `line`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `description` (`description`),
  ADD KEY `depart` (`depart`),
  ADD KEY `arrive` (`arrive`),
  ADD KEY `company` (`company`);

--
-- Ευρετήρια για πίνακα `prefecture`
--
ALTER TABLE `prefecture`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prefecture_country` (`country`),
  ADD KEY `phonecode` (`phonecode`);

--
-- Ευρετήρια για πίνακα `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country` (`country`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Μοναδικό Αναγνωριστικό', AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT για πίνακα `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT για πίνακα `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT για πίνακα `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT για πίνακα `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT για πίνακα `flight`
--
ALTER TABLE `flight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT για πίνακα `line`
--
ALTER TABLE `line`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT για πίνακα `prefecture`
--
ALTER TABLE `prefecture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT για πίνακα `rates`
--
ALTER TABLE `rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`flight`) REFERENCES `flight` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `city_ibfk_1` FOREIGN KEY (`prefecture`) REFERENCES `prefecture` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `company_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`city`) REFERENCES `city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `customerfaxes`
--
ALTER TABLE `customerfaxes`
  ADD CONSTRAINT `phonefax_ibfk_2` FOREIGN KEY (`customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `customerphones`
--
ALTER TABLE `customerphones`
  ADD CONSTRAINT `phonefax_ibfk_1` FOREIGN KEY (`customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `customer_email`
--
ALTER TABLE `customer_email`
  ADD CONSTRAINT `customer_email_ibfk_1` FOREIGN KEY (`customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `flight`
--
ALTER TABLE `flight`
  ADD CONSTRAINT `flight_ibfk_1` FOREIGN KEY (`line`) REFERENCES `line` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `line`
--
ALTER TABLE `line`
  ADD CONSTRAINT `line_ibfk_1` FOREIGN KEY (`depart`) REFERENCES `city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `line_ibfk_2` FOREIGN KEY (`arrive`) REFERENCES `city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `line_ibfk_3` FOREIGN KEY (`company`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `prefecture`
--
ALTER TABLE `prefecture`
  ADD CONSTRAINT `prefecture_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `rates`
--
ALTER TABLE `rates`
  ADD CONSTRAINT `rates_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
